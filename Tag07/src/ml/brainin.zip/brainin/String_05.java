package ml.brainin;

import java.util.Scanner;

public class String_05 {
	public static void main(String[] args) {
		for (int i = 32; i< 127; i++) {
			System.out.println("ASCII-Wert ist : "+i +" , char ist :"+(char)i);
		}
		System.out.println("close .... done");
	}
}
