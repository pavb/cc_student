package ml.brainin.wettrennens;

public class Fahrrad extends Fahrzeug{

	public Fahrrad() {
		super("Fahrrad", 30);
		setDrivers(2);
		setGeschwindigkeit(20);

	}

}
