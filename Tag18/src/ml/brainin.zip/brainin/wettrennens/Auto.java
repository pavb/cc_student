package ml.brainin.wettrennens;

public class Auto extends Fahrzeug{

	public Auto() {
		super("Auto", 140);
		setDrivers(4);
		setGeschwindigkeit(150);

	}

}
