package ml.brainin.wettrennens;

public class Rennwagen extends Fahrzeug{

	public Rennwagen() {
		super("Rennwagen", 200);
		setGeschwindigkeit(200);

	}

}
