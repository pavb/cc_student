package ml.brainin.Aufgabe_1;

public class Test{
	public static void main (String[] args){
		Dreieck d = new Dreieck();
		System.out.println ("\nDas Dreieck hat den Umfang " + d.umfang() );
	}
}